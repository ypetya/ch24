#!/usr/bin/env ruby
# ch24 - 2009 / E

MIRROR_VERT = [ 
  4,3,2,1,0,
  9,8,7,6,5,
  14,13,12,11,10,
  19,18,17,16,15,
  24,23,22,21,20 ]

MIRROR_HORIZ = [
  20,21,22,23,24,
  15,16,17,18,19,
  10,11,12,13,14,
  5,6,7,8,9,
  0,1,2,3,4 ]

ROTATE = [
  4,9,14,19,24,
  3,8,13,18,23,
  2,7,12,17,22,
  1,6,11,16,21,
  0,5,10,15,20]

TR = [
  '(0)',
  '(5)',
  '(4)',
  '(1)',
  '(1,5)',
  '(1,4)',
  '(2)',
  '(2,5)',
  '(2,4)',
  '(3)',
  '(3,5)',
  '(3,4)'
]

KORNYEKE = [[-1,0],[0,-1],[0,1],[1,0]]
@@depth = 0
@@counter = 0


class PuzzType
  def [] row
    a row
  end

  def a row
    @data[row*@y .. ((row+1)*@y -1)] || ''
  end
end

class Elem < PuzzType
  attr_accessor :data,:elem_id,:trafo_index,:x0,:y0

  def initialize my_id,tr_index
    @x,@y = 5,5
    @data, @elem_id='',my_id
    @trafo_index = tr_index
  end

  def valid?
    @data =~ /\#/
  end

  def load f
    5.times do
      line = f.gets
      if line
        line = line.gsub(/\r\n/){''}
        @data+= line
      end
    end
  end

  def == vele
    vele.data == @data and elem_id == vele.elem_id
  end

  def do_with str,matrix
    a = ' ' * 25
    for x in 0..4 do
      for y in 0..4 do
        offset = x + 5*y
        a[offset] = (str[matrix[offset]] || ' ') 
      end
    end
    a
  end

  # szétforgatjuk és visszadobáljuk a létrejött elemeket a data-t már felsleges visszaadni
  def populate
    ret = [@data,do_with( @data, MIRROR_VERT),do_with( @data, MIRROR_HORIZ)]
    3.times do |i|
      3.times do |i1|
        ret << do_with(ret[i*3+i1],ROTATE)
      end
    end
    ret.shift
    ret
  end

  def to_s
    puts "Element\##{@elem_id},tr:#{@trafo_index}"
    for i in 0..4 do
      puts @data[ (i*5) .. (i*5+4) ]
    end
  end
end


class Table < PuzzType
  attr_accessor :data,:elements

  def initialize f
    @passed = []
    @x0,@y0,@off0 = 0,0,0
    @x,@y = f.gets.strip.split(',')
    @x = @x.to_i
    @y = @y.to_i
    @data=''
    @y.times{ @data+=f.gets.strip }
    @elements=[]
    puts "Table loaded #{@x},#{@y}"
  end

  def has_this dat
    @elements.each do |e|
      return true if e == dat
    end
    false
  end

  def push_and_populate e
    tomb = e.populate
    tomb.each_with_index do |el,i|
      pop = Elem.new(e.elem_id,i+1)
      pop.data = el
      @elements << pop unless has_this(pop)
    end
  end

  def onloaded
    puts "#{@elements.size} elements loaded. populating.."
    @elements.each { |e| push_and_populate(e) }
    puts "#{@elements.size} elements"
    #display_elements
  end

  def remove_elem_id e_id
    @elements.select{|e| e.elem_id == e_id}.each do |vel|
      @elements.delete(vel)
    end
  end

  def calc_c
    @y0 = @off0 / @x
    @x0 = @off0 % @x 
  end
  
  def calc_o
    @off0 = @y0*@y +@x0
  end
 
  def set_data_with_offset puzz_x,puzz_y,data
    @data[@x0 + puzz_x+(@y0 + puzz_y)*@x] = data
  end 

  def data_with_offset puzz_x,puzz_y
    return '#' if( puzz_x+@x0 >= @x) || (puzz_y+@y0 >= @y)
    @data[@x0 + puzz_x+(@y0 + puzz_y)*@x].chr
  end

  def pass e
    #puts "Table at off#{@off0}"
    #for x in 0..4 do
    #  for y in 0..4 do
    #    d = data_with_offset(x,y)
    #    o = (e[x][y] || 32).chr=='#' ? true : false 
    #    if (e[x][y] || 32).chr=='#' and d ==' '
    #      print 'o'
    #    else
    #      print o ? '.' : ' '
    #    end
    #  end
    #  print "\n"
    #end
    #STDIN.gets

    for x in 0..4 do
      for y in 0..4 do
        return false unless (e[x][y] || 32).chr==' ' or data_with_offset(x,y) ==' '
      end
    end
    #puts "illeszkedett! yupí!"
    #return false if lyukas
    true
  end


  def clear_lyuk
    #display
    @data = @data.gsub(/[0-9]/){' '}
  end

  def lyukas
    for x in -1..5 do
      for y in -1..5 do
        if data_with_offset(x,y) ==' ' and lyukas_flood(x,y) 
          clear_lyuk
          return true
        end
        clear_lyuk
      end
    end
    false
  end

  def lyukas_flood x,y,meret=0
    #display
    if meret > 9
      return false
    end
    my_lyuk = true
    KORNYEKE.each do |o|
      new_x, new_y = x + o.first, y + o.last
      d = data_with_offset(new_x,new_y)
      if( d == ' ')
        set_data_with_offset(x,y,meret.to_s)
        return false unless lyukas_flood(new_x,new_y,meret+1)
      end
    end
    true
  end

  # szépen kiírjuk az outputot
  def vege
    File.open( "#{ARGV[0].split('.')[0]}.out", 'w' ) do |f|
      @passed.each do |e|
        f.puts( "#{e.elem_id},#{e.x0},#{e.y0},#{TR[e.trafo_index]}")
      end      
    end 
    true
  end
  
  def start
    while not pass_first_item
      @off0 += 1
      @off0 = 0 if @off0 > @x*@y
    end
    return true
  end

  def pass_first_item
    display
    off_buf = @off0
    @off0 +=1 if @off0 <= @data.size
    calc_c
    return vege if @elements.size == 0 
    return false if @off0 >= @data.size
    raktunk_fel = false
    @elements.each do |e|
      if pass(e)
        put_to_table(e)
        if lyukas
          remove_from_table
          next
        end
        raktunk_fel = true
        return true if pass_first_item 
      end
    end
    
    #ha ide értünk vmi gond, van, ide nem illeszthető.
    #remove_from_table if raktunk_fel
    @off0=off_buf
    return false
  end

  def put_to_table(e)
    e.x0 = @x0
    e.y0 = @y0
    @passed << e
    remove_elem_id( e.elem_id )
    #fel kell másolni a táblára!!
    for x in 0..4 do
      for y in 0..4 do
        set_data_with_offset( x,y,'#') if (e[x][y] || 32).chr == '#'
      end
    end
    #puts "#{e.elem_id}. felteve!(#{@x0},#{@y0})"
    #display
    @@counter+=1
    @@depth+=1
  end
  
  def display
    puts "Total try:#{@@counter} Depth:#{@@depth}"
    for i in 0..@y do
      puts a(i)
    end
    #STDIN.gets
  end
  
  def display_elements
    @elements.each do |e|
      puts e
      STDIN.gets
    end
  end

  def remove_from_table
    #le kell szedni a tábláról és visszatenni
    e = @passed.pop
    return unless e
    @x0,@y0 = e.x0,e.y0
    calc_o
    for x in 0..4 do
      for y in 0..4 do
        set_data_with_offset( x,y,' ') if (e[x][y] || 32).chr == '#'
      end
    end
    @elements << e
    push_and_populate(e)
    #puts "#{e.elem_id}. leveve!(#{@x0},#{@y0})"
    @@depth-=1
  end

end

l= 0
elem_id = 0
File.open( ARGV[0]) do |f|
  @@t=Table.new(f)
  line = nil
  while(line = f.gets)
    e = Elem.new(elem_id,0)
    e.load(f)
    @@t.elements << e if e.valid? 
    elem_id += 1
  end
end

@@t.onloaded
puts 'siker' if @@t.start

puts "ready"
